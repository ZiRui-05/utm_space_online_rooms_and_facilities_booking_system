<?php
$currentPage = $currentPage ?? '';

$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$prefix = strpos($scriptName, '/pages/') !== false ? '../../' : '';
$toRoot = static fn(string $path): string => $prefix . ltrim($path, '/');
?>
<style>
    .navbar {
        background: var(--primary-color);
        padding: 16px 30px;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 16px;
        position: sticky;
        top: 0;
        z-index: 100;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .navbar-left { display: flex; align-items: center; gap: 40px; min-width: 0; }
    .navbar-logo { font-size: 18px; font-weight: 700; color: var(--white); letter-spacing: 1px; margin: 0; }
    .nav-links { display: flex; gap: 30px; flex-wrap: wrap; min-width: 0; }
    .nav-link {
        color: var(--white);
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: color 0.3s;
        position: relative;
    }
    .nav-link:hover, .nav-link.active { color: var(--accent-color); }
    .nav-link.active::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 2px;
        background: var(--accent-color);
    }
    .navbar-right { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; min-width: 0; }
    .icon-button { background: none; border: none; font-size: 20px; cursor: pointer; transition: transform 0.3s; color: var(--white); display: block; }
    .icon-button:hover { transform: scale(1.1); }
    .btn-book-now {
        background-color: #FFC107 !important; /* Forces your golden yellow color */
        color: #1A202C !important;            /* Ensures text is dark and legible */
        border: none;
        padding: 8px 20px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .btn-book-now:hover {
        background-color: #E0A800 !important; /* Darker gold shift on hover */
        transform: translateY(-2px); 
        box-shadow: 0 4px 12px rgba(255, 193, 7, 0.4); 
    }
    /* Notification Wrap & Badge Configurations */
    .noti-dropdown-container { position: relative; display: inline-block; }
    .noti-badge {
        position: absolute;
        top: -2px;
        right: -2px;
        background-color: var(--danger, #dc3545);
        color: var(--white, #fff);
        font-size: 10px;
        font-weight: bold;
        padding: 2px 6px;
        border-radius: 10px;
        line-height: 1;
    }

    /* Professional Notification Pop-out Frame */
    .noti-menu {
        position: absolute; top: 45px; right: -50px; background: var(--white); border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15); width: 340px; z-index: 1000; overflow: hidden;
        border: 1px solid var(--border-light, #edf2f7);
    }
    .noti-header {
        display: flex; justify-content: space-between; align-items: center;
        padding: 12px 16px; border-bottom: 1px solid var(--border-light, #edf2f7);
        background: var(--bg-light, #f8f9fa);
    }
    .noti-header h3 { margin: 0; font-size: 14px; font-weight: 600; color: var(--text-dark); }
    .noti-clear-btn { background: none; border: none; color: #3182ce; font-size: 11px; cursor: pointer; padding: 0; }
    .noti-clear-btn:hover { text-decoration: underline; }
    
    .noti-body { max-height: 280px; overflow-y: auto; }
    .noti-item {
        display: flex; gap: 12px; padding: 12px 16px; border-bottom: 1px solid var(--border-light, #f7fafc);
        cursor: pointer; transition: background 0.2s; text-decoration: none; align-items: flex-start;
    }
    .noti-item:hover { background: var(--bg-light, #f8f9fa); }
    .noti-item.unread { background: #f0f7ff; }
    .noti-item-icon { font-size: 16px; margin-top: 2px; }
    .noti-item-content p { margin: 0 0 4px 0; font-size: 12px; color: var(--text-dark); line-height: 1.4; text-align: left; }
    .noti-item-content strong { display:block; font-size:12px; color:var(--text-dark); margin-bottom:3px; }
    .noti-item-time { font-size: 10px; color: #a0aec0; display: block; }
    
    .noti-footer { padding: 10px; text-align: center; background: var(--bg-light, #f8f9fa); border-top: 1px solid var(--border-light, #edf2f7); }
    .noti-footer a { color: #3182ce; text-decoration: none; font-size: 12px; font-weight: 500; }
    .noti-footer a:hover { text-decoration: underline; }

    /* Existing User Dropdown Layout Rules */
    .user-dropdown { position: relative; }
    .user-avatar {
        width: 36px; height: 36px; border-radius: 50%; background: var(--white);
        color: var(--primary-color); border: none; font-weight: 700; cursor: pointer; transition: all 0.3s;
        display: inline-flex; align-items: center; justify-content: center; line-height: 1;
        overflow: hidden;
    }
    .user-avatar img {
        width: 100%;
        min-width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }
    .user-avatar.has-image {
        padding: 0;
        background: var(--white);
        color: transparent;
    }
    .user-avatar:hover { transform: scale(1.1); }
    .dropdown-menu {
        position: absolute; top: 45px; right: 0; background: var(--white); border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); min-width: 200px; padding: 8px 0; z-index: 1000;
    }
    .dropdown-item {
        display: block; width: 100%; padding: 12px 20px; text-align: left; border: none;
        background: none; cursor: pointer; font-size: 13px; color: var(--text-dark); text-decoration: none; transition: background 0.3s;
    }
    .dropdown-item:hover { background: var(--bg-light); }
    .dropdown-item.logout { color: var(--danger); }
    .dropdown-divider { margin: 8px 0; border: none; border-top: 1px solid var(--border-light); }
    
    @media (max-width: 768px) {
        .navbar { flex-direction: column; gap: 12px; padding: 12px 16px; }
        .navbar-left { width: 100%; flex-direction: column; gap: 12px; align-items: flex-start; }
        .navbar-right { width: 100%; justify-content: space-between; }
        .nav-links { flex-direction: column; gap: 8px; }
        .noti-menu { right: auto; left: 0; width: calc(100vw - 32px); }

    .navbar{
        display:flex;
        flex-direction:column;
        align-items:center;
        padding:20px;
        gap:20px;
    }

    .navbar-left{
        width:100%;
        display:flex;
        flex-direction:column;
        align-items:center;
    }

    .navbar-logo{
        margin-bottom:15px;
        text-align:center;
    }

    .nav-links{
        width:100%;
        display:flex;
        flex-direction:row;
        justify-content:space-around;
        align-items:center;
    }

    .navbar-right{
        width:100%;
        display:flex;
        justify-content:space-around;
        align-items:center;
        position:static !important;
    }

    .btn-book-now{
        width:auto;
        margin:0;
    }
    }

    /* ── Shared mobile baseline (all user-facing pages) ─────────────── */
    @media (max-width: 768px) {
        /* Images never overflow their containers */
        img { max-width: 100%; height: auto; }
        /* Breadcrumbs use tighter side padding on phones */
        .breadcrumb { padding: 12px 16px; }
    }
</style>

<nav class="navbar">
    <div class="navbar-left">
        <h1 class="navbar-logo">SPACEBOOK</h1>
        <div class="nav-links">
            <a href="<?= htmlspecialchars($toRoot('homepage.php'), ENT_QUOTES, 'UTF-8') ?>" class="nav-link<?= $currentPage === 'home' ? ' active' : '' ?>">Home</a>
            <a href="<?= htmlspecialchars($toRoot('pages/app/room-availability.php'), ENT_QUOTES, 'UTF-8') ?>" class="nav-link<?= $currentPage === 'room' ? ' active' : '' ?>">Rooms</a>
            <a href="<?= htmlspecialchars($toRoot('pages/app/facilities.php'), ENT_QUOTES, 'UTF-8') ?>" class="nav-link<?= $currentPage === 'facilities' ? ' active' : '' ?>">Facilities</a>
        </div>
    </div>

    <div class="navbar-right">
        <div class="noti-dropdown-container" id="noti-container">
            <button class="icon-button" id="noti-btn" onclick="toggleNotiMenu(event)" title="Notification">
                🔔<span class="noti-badge" id="noti-badge" style="display:none;">0</span>
            </button>
            
            <div class="noti-menu" id="noti-menu" style="display:none;">
                <div class="noti-header">
                    <h3>Notifications</h3>
                    <button class="noti-clear-btn" onclick="markAllNotificationsAsRead()">Mark all as read</button>
                </div>
                <div class="noti-body" id="noti-body">
                    <div class="noti-item">
                        <span class="noti-item-icon">🔔</span>
                        <div class="noti-item-content">
                            <p>Loading notifications...</p>
                            <span class="noti-item-time">Please wait</span>
                        </div>
                    </div>
                </div>
                <div class="noti-footer">
                    <a href="<?= htmlspecialchars($toRoot('pages/app/all_notifications.php'), ENT_QUOTES, 'UTF-8') ?>">View All Notifications</a>
                </div>
            </div>
        </div>

        <button id="book-now-btn" class="btn-book-now" onclick="window.location.href='<?= htmlspecialchars($toRoot('pages/app/booking.php'), ENT_QUOTES, 'UTF-8') ?>'">Book Now</button><a id="signin-btn" class="nav-link" href="<?= htmlspecialchars($toRoot('pages/auth/login.php'), ENT_QUOTES, 'UTF-8') ?>" style="display:none;">Sign In</a><a id="signup-btn" class="nav-link" href="<?= htmlspecialchars($toRoot('pages/auth/register.php'), ENT_QUOTES, 'UTF-8') ?>" style="display:none;">Sign Up</a>

        <div class="user-dropdown" id="user-dropdown">
            <button class="user-avatar" id="user-avatar-btn" onclick="toggleUserMenu(event)">U</button>
            <div class="dropdown-menu" id="user-menu" style="display:none;">
                <a href="<?= htmlspecialchars($toRoot('pages/app/profile.php'), ENT_QUOTES, 'UTF-8') ?>" class="dropdown-item">👤 My Profile</a>
                <a href="<?= htmlspecialchars($toRoot('manager_admin/admin_dashboard.php'), ENT_QUOTES, 'UTF-8') ?>" class="dropdown-item" id="admin-profile-link" style="display:none;">🛡️ Admin Dashboard</a>
                <a href="<?= htmlspecialchars($toRoot('manager_admin/facility_manager_dashboard.php'), ENT_QUOTES, 'UTF-8') ?>" class="dropdown-item" id="facility-manager-dashboard-link" style="display:none;">🏢 Facility Manager Dashboard</a>
                <a href="<?= htmlspecialchars($toRoot('pages/app/booking-history.php'), ENT_QUOTES, 'UTF-8') ?>" class="dropdown-item">📋 My Bookings</a>
                <a href="#" class="dropdown-item">⚙️ Settings</a>
                <a href="#" class="dropdown-item">❓ About</a>
                <hr class="dropdown-divider">
                <a href="<?= htmlspecialchars($toRoot('pages/app/logout.php'), ENT_QUOTES, 'UTF-8') ?>" class="dropdown-item logout" onclick="return handleLogout(event)">🚪 Logout</a>
            </div>
        </div>
    </div>
</nav>

<script>
    (function(){
        function computeInitials(fullName){
            const normalized = (fullName || '').trim();
            return (normalized.charAt(0) || 'U').toUpperCase();
        }

        async function hydrateAvatar(){
            const avatar = document.getElementById('user-avatar-btn');
            if (!avatar) return;
            const setInitialAvatar = function(fullName){
                avatar.classList.remove('has-image');
                avatar.innerHTML = '';
                avatar.textContent = computeInitials(fullName);
            };
            const setImageAvatar = function(base64, mime){
                if (!base64 || !mime) return false;
                const image = document.createElement('img');
                image.src = `data:${mime};base64,${base64}`;
                image.alt = 'Profile picture';
                avatar.classList.add('has-image');
                avatar.innerHTML = '';
                avatar.appendChild(image);
                return true;
            };

            try {
                const localUser = JSON.parse(localStorage.getItem('userData') || 'null');
                const fullName = localUser?.full_name || localUser?.name;
                if (fullName) {
                    setInitialAvatar(fullName);
                }
            } catch (error) {
                console.warn('Unable to parse local user data for avatar.', error);
            }

            const noti = document.getElementById('noti-container');
            const signinBtn = document.getElementById('signin-btn');
            const signupBtn = document.getElementById('signup-btn');
            const avatarBtn = document.getElementById('user-avatar-btn');
            const bookNowBtn = document.getElementById('book-now-btn');

            const setGuestView = function() {
                if (noti) noti.style.display = 'none';
                if (bookNowBtn) bookNowBtn.style.display = 'none';
                if (signinBtn) signinBtn.style.display = 'inline-block';
                if (signupBtn) signupBtn.style.display = 'inline-block';
                if (avatarBtn) avatarBtn.onclick = () => window.location.href = '<?= htmlspecialchars($toRoot('pages/auth/login.php'), ENT_QUOTES, 'UTF-8') ?>';
            };

            const setAuthenticatedView = function() {
                if (noti) noti.style.display = 'inline-block';
                if (bookNowBtn) bookNowBtn.style.display = 'inline-block';
                if (signinBtn) signinBtn.style.display = 'none';
                if (signupBtn) signupBtn.style.display = 'none';
                if (avatarBtn) avatarBtn.onclick = (event) => toggleUserMenu(event);
            };

            setGuestView();

            try {
                const sessionResponse = await fetch('<?= htmlspecialchars($toRoot('api/auth/auth_session.php'), ENT_QUOTES, 'UTF-8') ?>', {
                    credentials: 'same-origin'
                });
                if (!sessionResponse.ok) return;

                const sessionData = await sessionResponse.json();
                if (!sessionData?.authenticated) {
                    return;
                }

                setAuthenticatedView();
                loadUserNotifications();
                const adminProfileLinkEarly = document.getElementById('admin-profile-link');
                const facilityManagerDashboardLinkEarly = document.getElementById('facility-manager-dashboard-link');
                if (adminProfileLinkEarly && sessionData.user?.role === 'admin') {
                    adminProfileLinkEarly.style.display = 'block';
                }
                if (facilityManagerDashboardLinkEarly && sessionData.user?.role === 'facility_manager') {
                    facilityManagerDashboardLinkEarly.style.display = 'block';
                }

                const sessionUser = sessionData.user || null;
                const fullName = sessionUser?.full_name || sessionUser?.name;
                if (!fullName) return;

                setInitialAvatar(fullName);
                localStorage.setItem('userData', JSON.stringify(sessionUser));

                const profileResponse = await fetch('<?= htmlspecialchars($toRoot('api/user/profile_data.php'), ENT_QUOTES, 'UTF-8') ?>', {
                    credentials: 'same-origin'
                });
                if (!profileResponse.ok) return;

                const profileData = await profileResponse.json();
                if (!profileData?.success || !profileData?.user) return;

                const profileUser = profileData.user;
                const adminProfileLink = document.getElementById('admin-profile-link');
                const facilityManagerDashboardLink = document.getElementById('facility-manager-dashboard-link');
                if (adminProfileLink && (profileUser.role === 'admin' || sessionUser?.role === 'admin')) {
                    adminProfileLink.style.display = 'block';
                }
                if (facilityManagerDashboardLink && (profileUser.role === 'facility_manager' || sessionUser?.role === 'facility_manager')) {
                    facilityManagerDashboardLink.style.display = 'block';
                }
                setImageAvatar(profileUser.profile_image_base64, profileUser.profile_image_mime);
            } catch (error) {
                setGuestView();
                console.warn('Unable to load session user data for avatar.', error);
            }
        }

        // Dropdown controls with event.stopPropagation to prevent conflicting click captures
        window.toggleUserMenu = function toggleUserMenu(e){
            if(e) e.stopPropagation();
            const userMenu = document.getElementById('user-menu');
            const notiMenu = document.getElementById('noti-menu');
            
            if (notiMenu) notiMenu.style.display = 'none';
            if (userMenu) {
                userMenu.style.display = userMenu.style.display === 'block' ? 'none' : 'block';
            }
        };

        window.toggleNotiMenu = function toggleNotiMenu(e){
            if(e) e.stopPropagation();
            const userMenu = document.getElementById('user-menu');
            const notiMenu = document.getElementById('noti-menu');
            
            if (userMenu) userMenu.style.display = 'none';
            if (notiMenu) {
                notiMenu.style.display = notiMenu.style.display === 'block' ? 'none' : 'block';
            }
        };

        function notificationIcon(type) {
            const map = { booking_status: '📅', booking_request: '📅', return_overdue: '⚠️', account: '👤', security: '🔐', payment: '💳', issue_report: '⚠️', profile: '🪪' };
            return map[type] || '🔔';
        }

        function timeLabel(value) {
            if (!value) return '';
            const date = new Date(String(value).replace(' ', 'T'));
            return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
        }

        function renderNotifications(payload) {
            const body = document.getElementById('noti-body');
            const badge = document.getElementById('noti-badge');
            if (!body || !badge) return;
            const unreadCount = Number(payload?.unread_count || 0);
            badge.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
            badge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
            const items = Array.isArray(payload?.notifications) ? payload.notifications : [];
            if (items.length === 0) {
                body.innerHTML = '<div class="noti-item"><span class="noti-item-icon">🔔</span><div class="noti-item-content"><p>No notifications yet.</p><span class="noti-item-time">Account activity will appear here.</span></div></div>';
                return;
            }
            body.innerHTML = items.map(item => `
                <a class="noti-item ${Number(item.is_read) === 0 ? 'unread' : ''}" href="<?= htmlspecialchars($toRoot('pages/app/all_notifications.php'), ENT_QUOTES, 'UTF-8') ?>">
                    <span class="noti-item-icon">${notificationIcon(item.notification_type)}</span>
                    <div class="noti-item-content">
                        <strong>${String(item.title || 'Notification').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}</strong>
                        <p>${String(item.message || '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}</p>
                        <span class="noti-item-time">${timeLabel(item.created_at)}</span>
                    </div>
                </a>
            `).join('');
        }

        async function loadUserNotifications() {
            try {
                const response = await fetch('<?= htmlspecialchars($toRoot('api/user/notifications.php'), ENT_QUOTES, 'UTF-8') ?>', { credentials: 'same-origin' });
                if (!response.ok) return;
                const data = await response.json();
                if (data?.success) renderNotifications(data);
            } catch (error) {
                console.warn('Unable to load notifications.', error);
            }
        }

        window.markAllNotificationsAsRead = async function markAllNotificationsAsRead() {
            try {
                await fetch('<?= htmlspecialchars($toRoot('api/user/notifications.php'), ENT_QUOTES, 'UTF-8') ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'same-origin',
                    body: JSON.stringify({ action: 'mark_all_read' })
                });
            } catch (error) {
                console.warn('Unable to mark notifications as read.', error);
            }
            document.querySelectorAll('.noti-item.unread').forEach(item => item.classList.remove('unread'));
            const badge = document.getElementById('noti-badge');
            if (badge) badge.style.display = 'none';
        };

        window.handleLogout = function handleLogout(event){
            localStorage.removeItem('userData');
            try { sessionStorage.clear(); } catch (error) {}
            const logoutUrl = '<?= htmlspecialchars($toRoot('pages/app/logout.php'), ENT_QUOTES, 'UTF-8') ?>';
            if (event) {
                // Let the real logout PHP page handle the redirect so logout still works if fetch/AJAX fails.
                return true;
            }
            window.location.href = logoutUrl;
            return false;
        };

        // Universal close catcher for clicking outside either active menu structure
        document.addEventListener('click', function(event){
            const userDropdown = document.querySelector('.user-dropdown');
            const notiDropdown = document.querySelector('.noti-dropdown-container');
            
            if (userDropdown && !userDropdown.contains(event.target)) {
                const userMenu = document.getElementById('user-menu');
                if (userMenu) userMenu.style.display = 'none';
            }
            if (notiDropdown && !notiDropdown.contains(event.target)) {
                const notiMenu = document.getElementById('noti-menu');
                if (notiMenu) notiMenu.style.display = 'none';
            }
        });

        document.addEventListener('DOMContentLoaded', hydrateAvatar);
    })();
</script>
